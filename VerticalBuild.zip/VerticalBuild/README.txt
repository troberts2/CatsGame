Hello welcome to the first playable version of cat's birthday game!



Please take the time to read this before playing!



To start off with the game:
	-MAKE SURE YOU "EXTRACT ALL" FROM THE .ZIP FILE THE GAME IS IN. IT MAY NOT WORK IF NOT.
	-This is a very quickly put together test build. May have more than one glitch I have not
	accounted for. Please not any bugs/interactions you do not think are intended during play.
	-I have made the first 3 levels and have a sample level. All are playable from level
	select.
	-I obviously have a lot to add and work on any criticism is valid, so feel free to fire away.
	-If it feels like context for something is missing I will probably add explanation through
	dialogue/story soon.
	-I do intend to add a tutorial.

Controls:
	-WASD to move and jump
	-SPACE to dash
	-Q to pencil attack
	-E to sprinkler attack
	-R to squigle attack
	-Note: planning on changing the attack keys (they don't feel good to me)
	-Note: Controller support is there but may not be fully implemented


AFTER PLAYING PLEASE COMPLETE THIS SHORT SURVEY ABOUT THE GAME IN YOUR BROWSER:
https://forms.gle/mE7myJxibrjQZCYQA